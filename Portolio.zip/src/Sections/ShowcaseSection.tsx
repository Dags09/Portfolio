import { useRef } from "react";
import { gsap } from "gsap/gsap-core";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "@gsap/react";
import AnimatedCounter from "../Components/AnimatedCounter";
gsap.registerPlugin(ScrollTrigger);

export default function ShowcaseSection() {
    const sectionRef = useRef(null);
    const project1Ref = useRef(null);
    const project2Ref = useRef(null);
    // const project3Ref = useRef(null);

    useGSAP(() => {
        const projects = [
            project1Ref.current,
            project2Ref.current,
            // project3Ref.current,
        ];
        projects.forEach((card, index) => {
            gsap.fromTo(
                card,
                {
                    y: 50,
                    opacity: 0,
                },
                {
                    y: 0,
                    opacity: 1,
                    duration: 1,
                    delay: 0.15 * index,
                    scrollTrigger: {
                        trigger: card,
                        start: "top bottom-=100",
                    },
                },
            );
        });
        gsap.fromTo(
            sectionRef.current,
            { opacity: 1 },
            { opacity: 1, duration: 1.5 },
        );
    }, []);
    return (
        <div>
            <div className="relative z-10">
                <AnimatedCounter />
            </div>
            <section id="work" ref={sectionRef} className="app-showcase">
                <div className="w-full">
                    <div className="showcaselayout">
                        <div
                            ref={project1Ref}
                            className="first-project-wrapper"
                        >
                            <div className="image-wrapper">
                                <img
                                    src="/images/bym_project.png"
                                    alt="Order"
                                />
                            </div>
                            <div className="text-content">
                                <h2>BYM Order Pro Digital Platform</h2>
                                <p className="text-white-50 md:text-xl">
                                    A comprehensive e-commerce and order
                                    management tool built to help store owners
                                    streamline restocking, and manage supplier
                                    transactions digitally in one unified
                                    dashboard
                                </p>
                                <a
                                    href="#"
                                    className="group relative inline-block text-white-50 font-semibold hover:text-white transition-colors duration-300 whitespace-nowrap"
                                >
                                    <span>Demo Project</span>
                                    <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-white transition-all duration-300 group-hover:w-full"></span>
                                </a>
                            </div>
                        </div>
                        <div className="project-list-wrapper overflow-hidden">
                            <div ref={project2Ref} className="project">
                                <div className="image-wrapper bg-[#ffefeb]">
                                    <img
                                        src="/images/cms_project.png"
                                        alt="Project preview"
                                    />
                                </div>
                                <div className="project-info">
                                    <div className="project-copy">
                                        <h2>Cockpit Management System</h2>
                                        <p className="text-white-50">
                                            A web-based system that streamlines
                                            cockpit operations, including
                                            registration, scheduling, betting,
                                            rentals, and income management.
                                        </p>
                                    </div>
                                    <a
                                        href="https://sabonghub.vercel.app/"
                                        className="demo-link group relative inline-block text-white-50 font-semibold hover:text-white transition-colors duration-300 whitespace-nowrap p-1"
                                    >
                                        <span>Demo Project</span>
                                        <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-white transition-all duration-300 group-hover:w-full"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="more-project-wrapper">
                        <a
                            href="#work"
                            className="more-project-link group relative inline-block font-semibold text-white-50 hover:text-white transition-colors duration-300 whitespace-nowrap"
                        >
                            <span>More Project</span>
                            <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-white transition-all duration-300 group-hover:w-full"></span>
                        </a>
                    </div>
                </div>
            </section>
        </div>
    );
}
